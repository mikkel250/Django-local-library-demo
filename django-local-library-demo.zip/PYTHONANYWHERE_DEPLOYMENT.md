# Django Local Library - PythonAnywhere Deployment Guide

This guide will help you deploy your Django Local Library project to PythonAnywhere following the Mozilla tutorial recommendations.

## Pre-Deployment Checklist ✅

Your project is already prepared with:
- ✅ Environment variables configured
- ✅ Static files settings ready
- ✅ Security settings implemented
- ✅ Requirements.txt created
- ✅ Production settings available

## Step 1: Prepare Your Project for PythonAnywhere

### 1.1 Update .env for PythonAnywhere
Update your `.env` file with PythonAnywhere-specific settings:

```bash
# Django settings for PythonAnywhere
SECRET_KEY=$41b10o6xs6wedas!+!4ofhcz$wy*r)65mtn&)^7!45_qb1ubv
DEBUG=False
ALLOWED_HOSTS=yourusername.pythonanywhere.com

# Database settings (PythonAnywhere provides MySQL)
DB_NAME=yourusername$locallibrary
DB_USER=yourusername
DB_PASSWORD=your_mysql_password
DB_HOST=yourusername.mysql.pythonanywhere-services.com
DB_PORT=3306
```

### 1.2 Create PythonAnywhere-specific Settings
Create a settings file optimized for PythonAnywhere:

```python
# locallibrary/settings_pythonanywhere.py
from .settings import *
import os

# PythonAnywhere specific settings
DEBUG = False
ALLOWED_HOSTS = ['yourusername.pythonanywhere.com']

# Database configuration for PythonAnywhere MySQL
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': os.environ.get('DB_NAME', 'yourusername$locallibrary'),
        'USER': os.environ.get('DB_USER', 'yourusername'),
        'PASSWORD': os.environ.get('DB_PASSWORD', ''),
        'HOST': os.environ.get('DB_HOST', 'yourusername.mysql.pythonanywhere-services.com'),
        'PORT': int(os.environ.get('DB_PORT', '3306')),
        'OPTIONS': {
            'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
        },
    }
}

# Static files
STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')

# Media files
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')
```

## Step 2: Upload to PythonAnywhere

### 2.1 Create PythonAnywhere Account
1. Go to [PythonAnywhere.com](https://www.pythonanywhere.com/)
2. Sign up for a free account
3. Verify your email

### 2.2 Upload Your Code
**Option A: Using Git (Recommended)**
```bash
# In PythonAnywhere Bash console
git clone https://github.com/yourusername/Django-local-library-demo.git
cd Django-local-library-demo
```

**Option B: Using File Upload**
1. Zip your project locally
2. Upload via PythonAnywhere's file manager
3. Extract in your home directory

### 2.3 Set Up Virtual Environment
```bash
# In PythonAnywhere Bash console
python3 -m venv env
source env/bin/activate
pip install -r requirements.txt
```

## Step 3: Configure Web Application

### 3.1 Create Web App
1. Go to "Web" tab in PythonAnywhere dashboard
2. Click "Add a new web app"
3. Choose "Manual configuration"
4. Select Python 3.10 (or latest available)

### 3.2 Configure Virtual Environment
In the "Virtualenv" section, enter:
```
/home/yourusername/env
```

### 3.3 Configure WSGI File
Replace the contents of the WSGI file with:

```python
import os
import sys

# Add your project directory to the Python path
path = '/home/yourusername/Django-local-library-demo'
if path not in sys.path:
    sys.path.insert(0, path)

# Set the Django settings module
os.environ['DJANGO_SETTINGS_MODULE'] = 'locallibrary.settings_pythonanywhere'

# Import Django WSGI application
from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()
```

## Step 4: Configure Static Files

### 4.1 Collect Static Files
```bash
# In PythonAnywhere Bash console
cd Django-local-library-demo
source env/bin/activate
python manage.py collectstatic --noinput
```

### 4.2 Configure Static Files in Web App
In the "Web" tab, add these static file mappings:

| URL | Directory |
|-----|-----------|
| `/static/` | `/home/yourusername/Django-local-library-demo/staticfiles/` |
| `/media/` | `/home/yourusername/Django-local-library-demo/media/` |

## Step 5: Set Up Database

### 5.1 Create MySQL Database
1. Go to "Databases" tab
2. Click "Create a new database"
3. Name it `locallibrary`
4. Note the database credentials

### 5.2 Install MySQL Client
```bash
# In PythonAnywhere Bash console
source env/bin/activate
pip install mysqlclient
```

### 5.3 Run Migrations
```bash
# In PythonAnywhere Bash console
cd Django-local-library-demo
source env/bin/activate
python manage.py migrate
python manage.py createsuperuser
```

## Step 6: Final Configuration

### 6.1 Update Settings
Make sure to replace `yourusername` in all configuration files with your actual PythonAnywhere username.

### 6.2 Reload Web App
Click the "Reload" button in the Web tab.

### 6.3 Test Your Site
Visit `https://yourusername.pythonanywhere.com/`

## Step 7: Optional Enhancements

### 7.1 Custom Domain (Paid Plans)
If you have a custom domain:
1. Update `ALLOWED_HOSTS` in settings
2. Configure DNS to point to PythonAnywhere
3. Add domain in Web app configuration

### 7.2 SSL Certificate
PythonAnywhere provides free SSL certificates:
1. Go to Web tab
2. Click "Enable HTTPS"
3. Follow the instructions

### 7.3 Scheduled Tasks
For periodic tasks (if needed):
1. Go to "Tasks" tab
2. Set up cron jobs or scheduled tasks

## Troubleshooting

### Common Issues:

1. **Static files not loading**
   - Check static file mappings in Web tab
   - Ensure `collectstatic` was run
   - Verify file permissions

2. **Database connection errors**
   - Check database credentials
   - Ensure MySQL client is installed
   - Verify database exists

3. **Import errors**
   - Check virtual environment path
   - Ensure all dependencies are installed
   - Verify Python path in WSGI file

4. **Permission errors**
   - Check file ownership
   - Ensure proper directory permissions

### Useful Commands:

```bash
# Check logs
tail -f /var/log/yourusername.pythonanywhere.com.error.log

# Test Django
python manage.py check --deploy

# Collect static files
python manage.py collectstatic --noinput

# Run migrations
python manage.py migrate

# Create superuser
python manage.py createsuperuser
```

## Free Plan Limitations

- **CPU seconds**: 100 per day
- **Disk space**: 1GB
- **Custom domains**: Not available
- **Always-on tasks**: Not available
- **HTTPS**: Available

## Next Steps After Deployment

1. **Test all functionality** - Browse books, authors, etc.
2. **Add sample data** - Use Django admin to add books
3. **Monitor performance** - Check CPU usage in dashboard
4. **Set up backups** - Regular database exports
5. **Consider upgrades** - If you need more resources

## Support Resources

- [PythonAnywhere Help](https://help.pythonanywhere.com/)
- [Django on PythonAnywhere](https://help.pythonanywhere.com/pages/Django/)
- [Mozilla Django Tutorial](https://developer.mozilla.org/en-US/docs/Learn/Server-side/Django/Deployment)

Your Django Local Library should now be live on PythonAnywhere! 🚀
