# Django Local Library - Deployment Guide

This guide will help you deploy the Django Local Library project to production.

## Pre-deployment Checklist

### 1. Environment Setup

Create a `.env` file in the project root with the following variables:

```bash
# Django settings
SECRET_KEY=your-super-secret-key-here
DEBUG=False
ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com

# Database settings (for PostgreSQL)
DB_NAME=locallibrary
DB_USER=your_db_user
DB_PASSWORD=your_db_password
DB_HOST=localhost
DB_PORT=5432

# Email settings
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_HOST_USER=your-email@gmail.com
EMAIL_HOST_PASSWORD=your-app-password
ADMIN_EMAIL=admin@yourdomain.com
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Database Setup

For production, it's recommended to use PostgreSQL:

```bash
# Install PostgreSQL (Ubuntu/Debian)
sudo apt-get install postgresql postgresql-contrib

# Create database and user
sudo -u postgres psql
CREATE DATABASE locallibrary;
CREATE USER your_db_user WITH PASSWORD 'your_db_password';
GRANT ALL PRIVILEGES ON DATABASE locallibrary TO your_db_user;
\q
```

### 4. Run Deployment Preparation

```bash
python3 deploy.py
```

This script will:
- Run Django deployment checks
- Collect static files
- Run database migrations
- Create necessary directories

### 5. Web Server Configuration

#### Nginx Configuration

Create `/etc/nginx/sites-available/locallibrary`:

```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    
    location = /favicon.ico { access_log off; log_not_found off; }
    
    location /static/ {
        root /path/to/your/project;
    }
    
    location /media/ {
        root /path/to/your/project;
    }
    
    location / {
        include proxy_params;
        proxy_pass http://127.0.0.1:8000;
    }
}
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/locallibrary /etc/nginx/sites-enabled
sudo nginx -t
sudo systemctl restart nginx
```

### 6. WSGI Server

Install and configure Gunicorn:

```bash
pip install gunicorn
```

Create a systemd service file `/etc/systemd/system/locallibrary.service`:

```ini
[Unit]
Description=Gunicorn instance to serve locallibrary
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=/path/to/your/project
Environment="PATH=/path/to/your/project/venv/bin"
ExecStart=/path/to/your/project/venv/bin/gunicorn --workers 3 --bind unix:/path/to/your/project/locallibrary.sock locallibrary.wsgi:application

[Install]
WantedBy=multi-user.target
```

Start the service:
```bash
sudo systemctl start locallibrary
sudo systemctl enable locallibrary
```

### 7. SSL/HTTPS Setup

Install Certbot for Let's Encrypt:

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

### 8. Security Considerations

1. **Change the SECRET_KEY**: Generate a new secret key for production
2. **Set DEBUG=False**: Never run with DEBUG=True in production
3. **Use HTTPS**: Always use SSL in production
4. **Database Security**: Use strong passwords and limit database access
5. **File Permissions**: Ensure proper file permissions (644 for files, 755 for directories)
6. **Regular Updates**: Keep Django and dependencies updated

### 9. Monitoring and Logging

- Check logs in the `logs/` directory
- Monitor server resources
- Set up error reporting (Sentry, etc.)
- Regular backups of database and media files

### 10. Testing Deployment

After deployment, test:

1. Visit your site in a browser
2. Test user registration/login
3. Test all major functionality
4. Check static files are loading
5. Verify HTTPS is working
6. Test error pages

## Troubleshooting

### Common Issues

1. **Static files not loading**: Run `python manage.py collectstatic`
2. **Database errors**: Check database connection and run migrations
3. **Permission errors**: Check file permissions and user ownership
4. **502 Bad Gateway**: Check if Gunicorn is running and socket permissions

### Useful Commands

```bash
# Check Django deployment readiness
python manage.py check --deploy

# Collect static files
python manage.py collectstatic

# Run migrations
python manage.py migrate

# Create superuser
python manage.py createsuperuser

# Check Gunicorn status
sudo systemctl status locallibrary

# View logs
tail -f logs/django.log
```

## Production Settings

The project includes a `settings_production.py` file with production-optimized settings. To use it:

1. Set `DJANGO_SETTINGS_MODULE=locallibrary.settings_production`
2. Or modify your WSGI configuration to use the production settings

## Support

For issues and questions, refer to:
- [Django Deployment Checklist](https://docs.djangoproject.com/en/stable/howto/deployment/checklist/)
- [Django Security](https://docs.djangoproject.com/en/stable/topics/security/)
- [Mozilla Django Tutorial](https://developer.mozilla.org/en-US/docs/Learn/Server-side/Django/Deployment)
