####Your Local Library

This project is a mock "local library" site that with functioning database, admin priveleges, rendering based on logged in user, and more.
It is built with Django.
